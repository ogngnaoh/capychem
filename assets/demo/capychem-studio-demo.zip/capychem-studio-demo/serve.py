#!/usr/bin/env python3
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, parse_qs, urlencode
import argparse

parser = argparse.ArgumentParser(description="Serve the recorded CapyChem demo locally")
parser.add_argument("--port", type=int, default=5182)
args = parser.parse_args()
class DemoHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        url = urlsplit(self.path)
        document = url.path in ("/", "/index.html") or (
            "text/html" in self.headers.get("Accept", "") and not Path(url.path).suffix
        )
        query = parse_qs(url.query)
        if document and query.get("mode") != ["demo"]:
            query["mode"] = ["demo"]
            self.send_response(302)
            self.send_header("Location", url.path + "?" + urlencode(query, doseq=True))
            self.end_headers()
            return
        if document:
            self.path = "/index.html"
        super().do_GET()

handler = partial(DemoHandler, directory=str(Path(__file__).resolve().parent))
print(f"CapyChem recorded demo: http://127.0.0.1:{args.port}/?mode=demo", flush=True)
print("No API, model downloads or cloud account are required. Ctrl+C stops the server.")
try:
    ThreadingHTTPServer(("127.0.0.1", args.port), handler).serve_forever()
except KeyboardInterrupt:
    pass
